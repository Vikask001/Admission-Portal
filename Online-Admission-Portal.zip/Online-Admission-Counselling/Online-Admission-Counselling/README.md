# Online-Admission-Counselling
This is an addmission counselling system Java Swing.
To run this project u need to install Netbeans with (java 1.8 ) recommended .
Just Clone / Download And run
This Project uses File System as database.
